document.addEventListener('DOMContentLoaded', function () {
  bb.generate({
    data: {
      columns: [
    ["data1", 30, 200, 100, 400, 150, 250],
    ["data2", 50, 20, 10, 40, 15, 25]
      ]
    },
    size: {
      width: 500,
      height: 250
    },
    bindto: "#billLine"
  });

  bb.generate({
    data: {
      columns: [
  	["data1", 30, 200, 100, 400, 150, 250],
  	["data2", 130, 100, 140, 200, 150, 50]
      ],
      type: "bar"
    },
    bar: {
      width: {
        ratio: 0.5
      }
    },
    size: {
      width: 500,
      height: 250
    },
    bindto: "#billBar"
  });

  bb.generate({
    data: {
      columns: [
        ["setosa", 30],
  			["versicolor", 40],
  			["virginica", 20],
      ],
      type: "pie"
    },
    size: {
      width: 500,
      height: 250
    },
    bindto: "#billPie"
  });

  bb.generate({
  data: {
    x: "x",
    columns: [
	["x", "Data A", "Data B", "Data C", "Data D", "Data E"],
	["data1", 330, 350, 200, 380, 150],
	["data2", 130, 100, 30, 200, 80],
	["data3", 230, 153, 85, 300, 250]
    ],
    type: "radar",
    labels: true
  },
  radar: {
    axis: {
      max: 400
    },
    level: {
      depth: 4
    }
  },
  size: {
    width: 500,
    height: 250
  },
  bindto: "#billRader"
  });

});
